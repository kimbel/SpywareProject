/*
 * Created on 26 nov. 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package exemple.diffieHellman;

/**
 * La classe Diffie utilise les services du fournisseur de service crypto par d�faut.
 * Elle initie un �change de clef avec la machine dont l'adresse IP et le port de connexion sont
 * donn�s en ligne de commande.
 * @author Olivier Camp
 *
 */
public class Diffie {}
