/*
 * Created on 26 nov. 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package exemple.diffieHellman;

import java.security.AlgorithmParameterGenerator;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidParameterSpecException;

import javax.crypto.KeyAgreement;
import javax.crypto.spec.DHParameterSpec;

/**
 * @author Olivier
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class KeyExchanger implements Runnable {

	/**
	 * @param port
	 */
	public KeyExchanger(int port) {

		// TODO Auto-generated constructor stub
	}

	public void run() {}

	/**
	 * 
	 */
	public byte[] getSecret() {
		System.out.println(
			"Creating Diffie-Hellman parameters ...");
		AlgorithmParameterGenerator paramGen = null;
		try {
			paramGen = AlgorithmParameterGenerator.getInstance("DH");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println("This algorithm does not exist");
			System.exit(1);
		}
		paramGen.init(512);
		AlgorithmParameters params = paramGen.generateParameters();
		DHParameterSpec dhParamSpec = null;
		try {
			dhParamSpec =
				(DHParameterSpec)params.getParameterSpec(DHParameterSpec.class);
		} catch (InvalidParameterSpecException e1) {
			System.err.println("The parameter specification is not valid");
			e1.printStackTrace();
			System.exit(1);
		}
		System.out.println("Base : " + dhParamSpec.getG());
		System.out.println("Mod : " + dhParamSpec.getP());
		
		KeyPairGenerator kPairGen = null;
		try {
			kPairGen = KeyPairGenerator.getInstance("DH");
		} catch (NoSuchAlgorithmException e2) {
			System.err.println("This algorithm does not exist");
			e2.printStackTrace();
			System.exit(1);
		}
		try {
			kPairGen.initialize(dhParamSpec);
		} catch (InvalidAlgorithmParameterException e3) {
			System.err.println("This algorithm does not exist");
			e3.printStackTrace();
			System.exit(1);
		}
				KeyPair kPair = kPairGen.generateKeyPair();
		KeyAgreement keyAgree = null;
		try {
			keyAgree = KeyAgreement.getInstance("DH");
		} catch (NoSuchAlgorithmException e4) {
			System.err.println("This algorithm does not exist");
						e4.printStackTrace();
						System.exit(1);
		}
				try {
					keyAgree.init(kPair.getPrivate());
				} catch (InvalidKeyException e5) {
					// TODO Auto-generated catch block
					e5.printStackTrace();
					System.exit(1);
				}
		return null;
	}
}
