/*
 * Created on 26 nov. 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package exemple.diffieHellman;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * La classe Hellmann utilise les services du fournisseur de service crypto DSTC.
 * Elle r�pond � un �change de clef avec toute machine qui la contacte sur le num�ro 
 * de port pass� en ligne de commande. 
 * @author Olivier
 */
public class Hellman {
	private static int DEFAULT_PORT_NUMBER = 2000;

	private Hellman(int port) {
		while (true) {
//			Socket s = waitForRequest(port);
			initiateKeyExchange(port);
		}
	}

	/**
	 * @param port
	 */
	private void initiateKeyExchange(int port) {
		KeyExchanger exchanger=new KeyExchanger(port);
		byte[] secret=exchanger.getSecret();
		
		
	}

	/**
	 * 
	 */
	private Socket waitForRequest(int port) {
		ServerSocket serverSocket = null;
		try {
			serverSocket=new ServerSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("Cannot open port number : " + port);
			System.exit(1);
		}
		Socket socket=null;
		System.out.println(serverSocket);
		try {
			socket=serverSocket.accept();
		} catch (IOException e1) {
			e1.printStackTrace();
			System.exit(1);
		}
		return socket ;

	}

	public static void main(String[] args) {
		if (args.length > 1) {
			System.err.println("Too many arguments. ");
			System.err.println("java Hellman <portNumber>");
		}
		int port;
		port =
			(args.length != 0)
				? (Integer.parseInt(args[1]))
				: DEFAULT_PORT_NUMBER;
		new Hellman(port);

	}

}
