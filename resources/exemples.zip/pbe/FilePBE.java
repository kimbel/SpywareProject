package exemple.pbe;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Vector;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

/**
 * Cr��e le 15 nov. 2003<BR>
 * Cette classe permet le chiffrement ou le d�chiffrement DES d'un fichier 
 * et le stockage du r�sultat dans un autre fichier. La clef DES utilis�e pour le 
 * chiffrement ou le d�chiffrement est calcul�e � partir d'un mot de passe
 * pass� en argument. <BR>
 * On utilise cette classe de la fa�on suivante  : 
 * <code>java FilePBE motDePasse fichierEntree fichierSortie [chiffrement]</code>
 * o� :
 * <UL>
 * <LI><code>motDePasse</code> : est le mot de passe permettant de calculer la clef de 
 * chiffrement ou de d�chiffrement. 
 * <LI><code>fichierEntree</code>: est le nom du fichier que l'on souhaite chiffrer/d�chiffrer
 * <LI><code>fichierSortie</code>: est le nom du fichier dans lequel on souhaite
 * ranger le r�sultat
 * <LI><code>chiffrement</code>: est un param�tre optionnel indiquant si on souhaite chiffrer 
 * ou d�chiffrer fichierEntree. Si cet argument n'est pas sp�cifi�, on supposera qu'on 
 * travaille en mode chiffrement. S'il est sp�cifi� la valeur "0" indique qu'on souhaite 
 * travaille en mode d�chiffrement. Tout autre valeur indique qu'on souhaite travailler
 * en mode chiffrement. 
 * </UL> 
 * @author Olivier Camp
 */
public class FilePBE {

    /**
     * Affiche un message d'erreur et si l'erreur est fatale sort de l'application
     * avec un code de retour non-nul
     * @param message le message � afficher
     * @param fatal bool�en indiquant si l'erreur est fatale. 
     */
    public static void error(String message, boolean fatal) {
        /* On affiche le message et si l'erreur est fatale
         * on sort avec un retour non nul
         */
        System.err.println(message);
        if (fatal)
            System.exit(1);
    }

    /**
     * @param nomFichier le nom du fichier d'entr�e
     * @param password Le mot de passe permettant de calculer la clef de 
     * chiffrement/d�chiffrement.
     * @param chiffrement si true on chiffre sinon on d�chiffre
     * @param le nom du fichier de sortie. 
     */
    public FilePBE(
        String nomFichier,
        byte[] password,
        boolean chiffrement,
        String fichierSortie) {
        Vector vecteurClair, vecteurChiffr�;
        Cipher chiffreur;
        vecteurClair = lireFichier(nomFichier);
        affiche(vecteurClair); //DEBUG
        chiffreur = construireChiffreur(password, chiffrement);
        vecteurChiffr� = chiffre(chiffreur, vecteurClair);
        affiche(vecteurChiffr�); //DEBUG
        ecrire(vecteurChiffr�, fichierSortie);
    }

    /**
     * Imprime les octets contenus dans TableauByte dans le fichier
     * fichier. 
     * @param v vecteur de TableauByte
     * @param fichier nom de fichier
     */

    private void ecrire(Vector v, String fichier) {
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(fichier);
        } catch (FileNotFoundException e) {
            error("Le fichier de sortie n'existe pas", true);
        }
        for (int i = 0; i < v.size(); i++) {
            TableauByte tab = (TableauByte) (v.elementAt(i));
            byte[] tabb = tab.getTab();
            int n = tab.getLength();
            try {
                out.write(tabb, 0, n);
            } catch (IOException e1) {
                error("Probl�me d'�criture", true);
            }
        }
    }

    /**
     * Affiche tous les octets contenus dans <code>v</code> sur la sortie
     * standard
     * @param v un vecteur de TableauByte
     */
    private void affiche(Vector v) {
        for (int i = 0; i < v.size(); i++) {
            TableauByte tab = (TableauByte) (v.elementAt(i));
            byte[] tabb = tab.getTab();
            int n = tab.getLength();
            System.out.print(new String(tabb, 0, n));
        }
        System.out.println();
    }

    /**
     * 
     * @param chiffreur une instance de <code>Cipher</code> initialis�e en fonction du mode
     * de chiffrement/d�chiffrement choisi.
     * @param clair vecteur de TableauByte contenant tous les octets � chiffrer.
     * @return le vecteur de TableauByte chiffr�/d�chiffr� 
     */
    private Vector chiffre(Cipher chiffreur, Vector clair) {
        Vector v2 = new Vector();
        for (int i = 0; i < clair.size(); i++) {
            TableauByte tab = (TableauByte) (clair.elementAt(i));
            byte[] tabb = tab.getTab();
            int n = tab.getLength();
            byte[] tabb2 = null;
            if (i + 1 == clair.size()) {
                try {
                    tabb2 = chiffreur.doFinal(tabb, 0, n);
                } catch (IllegalStateException e) {
                    error("Etat interdit", true);
                } catch (IllegalBlockSizeException e) {
                    error("Taille de Bloc interdite", true);
                    System.err.println(e);
                } catch (BadPaddingException e) {
                    error(
                        "Mauvais Padding (peut �tre caus� par une mauvaise clef)",
                        true);
                }
            } else {
                tabb2 = chiffreur.update(tabb, 0, n);
            }
            v2.add(new TableauByte(tabb2));
        }
        return v2;
    }

    private Cipher construireChiffreur(byte[] password, boolean chiffrement) {
        Cipher chiffreur = null;
        SecretKey clef = construireClef(password);
        String algoChiffrement = "DES";
        try {
            chiffreur = Cipher.getInstance(algoChiffrement);
        } catch (NoSuchAlgorithmException e) {
            System.out.println(e);
            error(
                "L'algorithme de chiffrement "
                    + algoChiffrement
                    + " n'existe pas.",
                true);
        } catch (NoSuchPaddingException e) {
            System.out.println(e);
            error("Probl�me avec l'algorithme de chiffrement ", true);
        }
        try {
            chiffreur.init(
                chiffrement ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE,
                clef);
        } catch (InvalidKeyException e1) {
            error("La clef de chiffrement n'est pas valide", true);
        }
        return chiffreur;
    }

    /**
     * Lit un fichier donn� et stocke les octets qu'il contient dans un vecteur de
     * TableauByte. La lecture dans le fichier se fait par blocs de 100 octets
     * � la fois. 
     * @param nomFichier le nom du fichier � lire
     * @return un vecteur de TableauByte contenant tous les octets du fichier. 
     */
    private Vector lireFichier(String nomFichier) {
        Vector vecteurFichier = new Vector();
        // Avant de commencer on v�rifie que le fichier existe
        FileInputStream in = null;
        try {
            in = new FileInputStream(nomFichier);
        } catch (FileNotFoundException e) {
            error("Le fichier " + nomFichier + " n'existe pas.", true);
        }
        byte[] lu = new byte[100];
        int retour = 0;
        while (retour != -1) {
            // On lit le fichier par bloc de 100 octets
            // et on stocke ces blocs dans le vecteur vecteurFichier
            // Les blocs sont stock�s sous la forme de TableauByte 
            // car d'apr�s les specs de Vector on doit ranger des 
            // Object dans un vecteur
            try {
                retour = in.read(lu, 0, 100);
            } catch (IOException e) {
                error("Probl�me de lecture", true);
            }
            if (retour != -1) {
                vecteurFichier.add(new TableauByte(lu, retour));
                lu = new byte[100];
            }
        }
        try {
            in.close();
        } catch (IOException e1) {
            error("Probl�me lors de la fermeture du fichier d'entr�e", false);
        }
        // On retourne le vecteur de lignes
        return vecteurFichier;

    }

    /**
     * Calcule l'empreinte SHA-1 d'un mot de passe
     * @param password le mot de passe
     * @return l'empreinte du mot de passe pass� en param�tre. 
     */
    private byte[] hache(byte[] password) {
        String algo = "SHA-1";
        MessageDigest hachoir = null;
        try {
            hachoir = MessageDigest.getInstance(algo);
        } catch (NoSuchAlgorithmException e) {
            error("L'algorithme de hachage " + algo + " n'existe pas!", true);
        }
        byte[] hachis = new byte[30];
        hachis = hachoir.digest(password);
        return hachis;
    }

    /**
     * @param password mot de passe
     * @return une clef secr�te construite � partir de l'empreinte du mot de passe
     * pass� en param�tre
     */

    private SecretKey construireClef(byte[] password) {
        DESKeySpec clef = null;
        byte[] hachis = hache(password);
        try {
            clef = new DESKeySpec(hachis);
        } catch (InvalidKeyException e1) {
            error("Probl�me lors de la construction de a clef" + e1, true);
        }
        //		System.out.println(clef.getKey());
        SecretKey key = null;
        try {
            key = SecretKeyFactory.getInstance("DES").generateSecret(clef);
        } catch (InvalidKeySpecException e2) {
            error("Mauvaise sp�cification de clef", true);
        } catch (NoSuchAlgorithmException e2) {
            error("L'algorithme DES n'existe pas", true);
        }
        return key;

    }
    /**
     * La fonction principale de la classe. C'est elle qui v�rifie que les bons arguments
     * ont �t� fournies et qui se charge de cr�er les instances n�cessaires et de 
     * leur envoyer les bons messages
     * @param args le tableau des arguments pass�s sur la ligne de commande. 
     */
    public static void main(String[] args) {
        if ((args.length > 4) || (args.length < 3)) {
            // La classe ne peut �tre utilis�e qu'avec 3 ou 4 arguments
            // On provoque une erreur et on sort
            System.err.println(
                "Utilisation : java FilePBE motDePasse fichierEntree fichierSortie [chiffrement]");
            return;
        } else {
            // S'il y a trois ou quatre arguments, 
            // le premier devrait �tre le mot de passe
            // le second le nom du fichier � chiffrer/d�chiffrer
            // le troisi�me le nom du fichier r�sultat
            // le quatri�me est 0 pour d�chiffrer et 1 pour chiffrer. 
            // Si le quatri�me argument est omis on suposera qu'on d�sire
            // chiffrer le fichier 
            String motDePasse = args[0],
                nomFichier = args[1],
                fichierSortie = args[2];
            boolean chiffrement;
            if (args.length == 4) {
                // Appel � quatre arguments
                chiffrement = (args[3].equals("0") ? false : true);
            } else {
                // Appel seulement 3 arguments
                chiffrement = true;
            }
            // Avant toute chose, on transforme le mot de passe en byte[]
            byte[] password = motDePasse.getBytes();
            // On peut forcer un nettoyage pour �tre s�r que la chaine arg[0] disparaisse de la m�moire
            // au plus vite
            motDePasse = args[0] = null;
            System.gc();

            new FilePBE(nomFichier, password, chiffrement, fichierSortie);
        }
    }
}