package exemple.pbe;

/**
 * Cr��e le 19 nov. 2003<BR>
 * Cette classe permet d'encapsuler un byte[] dans un objet.  
 * Ce qui est n�cessaire si nous souhaitons les stocker dans un Vecteur
 * @see FilePBE
 * @author Olivier Camp
 * 
 * 
 */
public class TableauByte {
    /** Le nombre d'octets contenu dans le tableau de byte */
    int nbChar;
    /** le tableau d'octets */
    byte[] tab;

    /** 
     * Constructeur permettant de cr�er une instance de TableauByte
     * contenant les <code>nbChar</code> premiers octets du tableau d'octets 
     * <code>tab</tab> 
     * @param tab un tableau d'octets
     * @param nbChar le nombre d'octets � consid�rer dans <code>tab</code>
     */
    TableauByte(byte[] tab, int nbChar) {
        this.tab = tab;
        this.nbChar = nbChar;
    }

    /** Constructeur permettant de cr�er une instance de TableauByte
    	* contenant tous les octets du tableau d'octets <code>tab</tab> 
    	* @param tab un tableau d'octets
    	*/
    TableauByte(byte[] tab) {
        this(tab, tab.length);
    }
    /**
     * 
     * @return Retourne le nombre d'octets contenu dans le TableauByte 
     */
    public int getLength() {
        return nbChar;
    }
    /**
     * 
     * @return le tableau d'octets (<code>byte[]</code>)
     */
    public byte[] getTab() {
        return tab;
    }
}
