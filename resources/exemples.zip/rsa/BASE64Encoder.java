package exemple.rsa;

import exemple.base64.Base64;

public class BASE64Encoder {
  public String encode(byte[] raw) {
    return Base64.encode(raw);
  }
}