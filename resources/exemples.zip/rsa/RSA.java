package exemple.rsa;

import java.security.KeyPairGenerator;
import java.security.SecureRandom;
import java.security.KeyPair;
import java.security.Provider;
import java.security.Security;
import java.security.NoSuchProviderException;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;

import java.security.interfaces.RSAPublicKey;
import java.security.interfaces.RSAPrivateKey;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;

/**
 * La classe RSA illustrent le chiffrement et le d�chiffrement RSA
 * On utilise pour cel�, le provider de service cryptographique fourni
 * par Wedgetail
 *  * @author <a href="mailto:olivier.camp@eseo.fr">Olivier Camp</a>
 * @version 1.0
 */
public class RSA {

    private static Provider addProviderDSTC() {
        // M�thode permettant d'ajouter le provider DSTC offrant le chiffrement RSA
        Provider dstc_provider = new com.dstc.security.provider.DSTC();
        int result = Security.addProvider(dstc_provider);
        if (result == -1) {
            return null;
        } else {
            return dstc_provider;
        }
    }

    public static void main(String[] args) {
		// Provider name
		String providerName="DSTC";
        // Ajout d'un provider particulier
        System.out.println(
            ">>>>>>>>>>>>>>>>> Tentative d'ajout du provider DSTC");
            Provider dstcProvider=addProviderDSTC();
        if (dstcProvider==null) {
            System.out.println(
                "DSTC n'a pas pu �tre ajout� � la liste des providers");
            System.exit(-1);
        } else {
            System.out.println("Le provider DSTC a �t� ajout�");
            System.out.println("Voici sa description :");
            System.out.println(dstcProvider.getInfo());
        }
        System.out.print(
            ">>>>>>>>>>>>>>>>> Tentative d'instanciation d'un KeyPairGenerator"
            +" pour l'algorithme RSA et le provider DSTC) :");
        // Cr�ation d'un g�n�rateur de paires de clefs pour l'algorithme RSA 
        KeyPairGenerator keyGen = null;
        try {

            keyGen = KeyPairGenerator.getInstance("RSA", providerName);
        } catch (NoSuchAlgorithmException e) {
            System.out.print("Echec de la cr�ation du KeyPairGenerator : ");
            System.out.println("l'algorithme RSA n'existe pas ");
            System.out.println(e);
            System.exit(1);
        } catch (NoSuchProviderException e) {
            System.out.print("Echec de la cr�ation du KeyPairGenerator : ");
            System.out.println("Le provider n'existe pas " + e);
            System.exit(1);
        }
        System.out.println("OK");
        /* Cr�ation d'un g�n�rateur al�atoire */
        System.out.print(
            ">>>>>>>>>>>>>>>>> Tentative d'instanciation de la source al�atoire (algorithme SHA1PRNG) :");
        SecureRandom random = null;
        try {
            random = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException e) {
            System.out.print(
                "Echec de l'instanciation de la source al�atoire :");
            System.out.println("l'algorithme SHA1PRNG n'existe pas ");
            System.exit(1);
        }
        System.out.println("OK");
        // Initialisation du g�n�rateur al�atoire
        System.out.println(
            ">>>>>>>>>>>>>>>>> Initialisation du g�n�rateur al�atoire");
        long userSeed = System.currentTimeMillis();
        random.setSeed(userSeed);
        System.out.println(" User seed = " + userSeed );
        /* Initialisation du g�n�rateur de clef avec la source al�atoire et une taille */
        System.out.print(
            ">>>>>>>>>>>>>>>>> Initialisation du g�n�rateur de clef :");
        keyGen.initialize(1024, random);
        System.out.println("OK");
        /* G�n�ration de la paire de clef */
        System.out.print(">>>>>>>>>>>>>>>>> Fabrication des clefs :");
        KeyPair pair = keyGen.generateKeyPair();
        System.out.println("==================================================================");
        System.out.println(
            "Clef publique : " + ((RSAPublicKey)pair.getPublic()));
		System.out.println("\n\n\n==================================================================");
        System.out.println(
            "Clef priv�e : " + ((RSAPrivateKey)pair.getPrivate()));

        Cipher rsaCipher = null;

        System.out.print(
            ">>>>>>>>>>>>>>>>> Tentative de cr�ation du chiffreur : ");
        try {
            rsaCipher = Cipher.getInstance("RSA", providerName);
        } catch (NoSuchAlgorithmException e) {
            System.out.print("Echec de la cr�ation du chiffreur : ");
            System.out.println("l'algorithme RSA n'existe pas ");
            System.out.println(e);
            System.exit(1);
        } catch (NoSuchPaddingException e) {
            System.out.print("Echec de la cr�ation du chiffreur : ");
            System.out.println("probl�me de padding ");
            System.exit(1);
        } catch (NoSuchProviderException e) {
            System.out.print("Echec de la cr�ation du chiffreur : ");
            System.out.println("le provider n'existe pas " + e);
            System.exit(1);
        }
        System.out.println("OK");
        System.out.println(
            ">>>>>>>>>>>>>>>>> Tentative d'initialisation du chiffreur en mode CHIFFREMENT avec la clef publique : ");
        //System.out.print(pair.getPublic());
        try {
            rsaCipher.init(Cipher.ENCRYPT_MODE, pair.getPublic());
        } catch (InvalidKeyException e) {
            System.out.println("Probl�me avec la clef");
            System.exit(1);
        }

        System.out.println(
            "====================================================================");
        String clair = "voici le message en clair que l'on veut chiffrer";
        byte[] chiffreByte = null;
        System.out.print(
            "Tentative de chiffrement du message : \""
                + clair
                + "\" avec la clef publique ");
        try {
            chiffreByte = rsaCipher.doFinal(clair.getBytes());
        } catch (Exception e) {
            System.out.println();
            System.err.println("Echec du chiffrement : " + e);
            System.exit(1);
        }
        System.out.println("OK");
        System.out.println(
            "====================================================================");
        String chiffre=new String(chiffreByte);
		System.out.println("Message chiffre (binaire) sur " + chiffre.length()+" caract�res : " + (chiffre));
        BASE64Encoder encoder = new BASE64Encoder();
        chiffre = encoder.encode(chiffreByte);
        System.out.println("Message chiffre (Base64) sur " + chiffre.length()+" caract�res : " + chiffre);
        System.out.println();
        System.out.println(
            "\n>>>>>>>>>>>>>>>>> Tentative d'initialisation du chiffreur pour le d�chiffrement avec la clef priv�e");
        //System.out.println(pair.getPrivate());
        try {
            rsaCipher.init(Cipher.DECRYPT_MODE, pair.getPrivate());
        } catch (InvalidKeyException e) {
            System.out.println("Probl�me avec la clef");
            System.exit(1);
        }
        byte[] clairByte = null;
        System.out.println(
            ">>>>>>>>>>>>>>>>> Tentative de d�chiffrement avec la clef priv�e");
        try {
            clairByte = rsaCipher.doFinal(chiffreByte);
        } catch (Exception e) {
            System.err.println("Probl�me de d�chiffrement : " + e);
        }
        clair = new String(clairByte);
        System.out.println("Texte d�chiffr� : \"" + clair + "\"");
    }

}
